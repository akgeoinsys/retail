## Environment:
- Spark Version: 3.0.1
- Python Version: 3.7

## Read-Only Files:
```
src/app.py
src/tests/*
src/main/__init__.py
src/main/base/*
src/main/job/__init__.py
make.sh
hackerrank.yml
README.md
requirements.txt
data/*
```

## Requirements:
In this challenge, you are going to write a spark job that contains information about gym memberships.. Basically you have to filter `membership.csv` file based on `enrollments.csv` file and do some data manipulation. Sample files are given in `data`. 

- `enrollments.csv`
  - it contains the data in the layout `memberId,firstName,lastName`
  - it is a csv file with one line per `memberId`
  
- `membership.csv`
  - it contains the data in the layout `memberId,fullName,paidAmount`
  - it is a csv file with one line per `memberId`

- `enrollments.csv - membership.csv`
  - Each member has one corresponding enrollment record

The project is partially completed and there are 4 methods and a spark session to be implemented in the file `src/main/job/pipeline.py`:

- `init_spark_session(self) -> SparkSession`:
  - create a spark session with master `local` and name `Data Cleaning`

- `filter_membership(self, enrollment: DataFrame, membership: DataFrame) -> DataFrame`:
  - remove all the rows from `membership` whose `memberId` is not present in `enrollment`
  - returned the filtered `membership`

- `generate_full_name(enrollment: DataFrame, membership: DataFrame) -> DataFrame`:
  - `fullName` column in `membership` is empty. So populate it by concatenating `firstName` and `lastName` column from `enrollment`
  - return the `membership`

- `find_max_paid_member(membership: DataFrame) -> str`:
  - find the member which has highest `paidAmount`
  - return the member's `memberId`

- `find_total_paid_amount(membership: DataFrame) -> int`:
  - find the sum of `paidAmount` column in the `membership`
  - return the total sum
    
Your task is to implement a PySpark application that performs various analysis tasks on the gym memberships dataset using RDDs. You need to write the necessary functions in the pipeline.py file to accomplish the following tasks:

## Commands
- run: 
```bash
source venv/bin/activate; python3 src/app.py data/enrollments.csv data/membership.csv
```
- install: 
```bash
bash make.sh __install; source venv/bin/activate; pip3 install -r requirements.txt
```
- test: 
```bash
source venv/bin/activate; py.test -p no:warnings
```