from pyspark.sql.types import StructType, StringType, StructField, IntegerType

enrollment = StructType([
    StructField("memberId", StringType()),
    StructField("firstName", StringType()),
    StructField("lastName", StringType())
])

membership = StructType([
    StructField("memberId", StringType()),
    StructField("fullName", StringType()),
    StructField("paidAmount", IntegerType())
])
