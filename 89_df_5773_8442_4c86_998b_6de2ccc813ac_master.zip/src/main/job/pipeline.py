import pyspark.sql.functions as f
from pyspark.sql import SparkSession, DataFrame, Window
from main.base import PySparkJobInterface


class PySparkJob(PySparkJobInterface):

    def init_spark_session(self) -> SparkSession:
        return SparkSession.builder.master('local[2]').appName('Data Cleaning').getOrCreate()

    def filter_membership(self, enrollment: DataFrame, memberships: DataFrame) -> DataFrame:
        # Write your code here

    def generate_full_name(self, enrollment: DataFrame, membership: DataFrame) -> DataFrame:
        # Write your code here

    def find_max_paid_member(self, memberships: DataFrame) -> str:
        # Write your code here

    def find_total_paid_amount(self, memberships: DataFrame) -> int:
        # Write your code here
