import pytest
from pyspark.sql import SparkSession
from main.job.pipeline import PySparkJob
from main.base import schema

job = PySparkJob()

elg_sample = [
    ("101", "Fizz", "Buzz"),
    ("103", "John", "Sena"),
]

med_sample = [
    ("101", None, 20),
    ("105", None, 60),
    ("103", None, 90)
]


def create_sample(sample, data_schema):
    return job.spark.createDataFrame(data=sample, schema=data_schema)


@pytest.mark.filterwarnings("ignore")
def test_init_spark_session():
    assert isinstance(job.spark, SparkSession), "-- spark session not implemented"


@pytest.mark.filterwarnings("ignore")
def test_filter_membership():
    enrollment = create_sample(elg_sample, schema.enrollment)
    memberships = create_sample(med_sample, schema.membership)

    filtered_membership = job.filter_membership(enrollment, memberships)
    membership_list = sorted(filtered_membership.collect(), key=lambda x: x.memberId)

    assert (2 == len(membership_list))
    assert ("101" == membership_list[0].memberId)
    assert ("103" == membership_list[1].memberId)


@pytest.mark.filterwarnings("ignore")
def test_generate_full_name():
    enrollment = create_sample(elg_sample, schema.enrollment)
    memberships = create_sample(med_sample, schema.membership)

    filtered_membership = job.filter_membership(enrollment, memberships)
    full_name = job.generate_full_name(enrollment, filtered_membership)

    membership_list = sorted(full_name.collect(), key=lambda x: x.memberId)

    assert (2 == len(membership_list))
    assert ("101" == membership_list[0].memberId and "Fizz Buzz" == membership_list[0].fullName)
    assert ("103" == membership_list[1].memberId and "John Sena" == membership_list[1].fullName)


@pytest.mark.filterwarnings("ignore")
def test_find_max_paid_member():
    memberships = create_sample(med_sample, schema.membership)

    max_paid_member = job.find_max_paid_member(memberships)
    assert max_paid_member == "103"


@pytest.mark.filterwarnings("ignore")
def test_find_total_paid_amount():
    memberships = create_sample(med_sample, schema.membership)

    total_paid_amount = job.find_total_paid_amount(memberships)
    assert total_paid_amount == 170
