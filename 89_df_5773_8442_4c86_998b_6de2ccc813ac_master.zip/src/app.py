import sys
import main.base.schema as schema
from main.job.pipeline import PySparkJob


enrollment_path = sys.argv[1]
membership_path = sys.argv[2]


def main():
    job = PySparkJob()

    # Load input data to DataFrame
    print("<<Reading>>")
    enrollment = job.read_csv(enrollment_path, schema.enrollment)
    membership = job.read_csv(membership_path, schema.membership)

    print("<<Filter>>")
    filtered_memberships = job.filter_membership(enrollment, membership)
    filtered_memberships.show()

    print("<<Full Name>>")
    full_names = job.generate_full_name(enrollment, filtered_memberships)
    full_names.show()

    print("<<Max Paid Member>>")
    max_paid_member = job.find_max_paid_member(filtered_memberships)
    print(max_paid_member)

    print("<<Total Paid Amount>>")
    total_paid_amount = job.find_total_paid_amount(filtered_memberships)
    print(total_paid_amount)
    job.stop()


if __name__ == '__main__':
    main()
