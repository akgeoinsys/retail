## Environment:
- Spark Version: 3.0.1
- Python Version: 3.7

## Requirements:
In this challenge, you are going to write a spark job that analyzes sports events. You have two input files: `players.csv` and `events.csv`. Sample files are given in `data`.

- `players.csv`
  - It contains the data in the layout `playerId,playerName,age,team`
  - It is a csv file with one line per `playerId`

- `events.csv`
  - It contains the data in the layout `eventId,playerId,eventType,timestamp`
  - It is a csv file with one line per `eventId`

The project is partially completed, and there are five methods and a spark session to be implemented in the file `src/main/job/pipeline.py`:

- `init_spark_session(self) -> SparkSession`:
  - Create a spark session with master `local` and name `Sports Event Analysis`

- `filter_events_by_type(self, event_type: str, events: DataFrame) -> DataFrame`:
  - Filter events based on the given `event_type`
  - Return the filtered `events`

- `count_events_by_player(self, events: DataFrame) -> DataFrame`:
  - Count the number of events per player
  - Return a DataFrame with the `playerId` and their event count

- `join_player_event_data(self, players: DataFrame, events: DataFrame) -> DataFrame`:
  - Join the `players` and `events` DataFrames on `playerId`
  - Return the joined DataFrame

- `find_most_popular_event(self, events: DataFrame) -> str`:
  - Find the most popular event type among all events
  - Return the `eventType` as a string

- `find_average_age_by_event_type(self, players: DataFrame, events: DataFrame) -> DataFrame`:
  - Find the average age of players for each event type
  - Return a DataFrame with the `eventType` and the corresponding average age

Your task is to complete the implementation of that job so that the unit tests pass while running the tests. You can use the given tests to check your progress while solving the problem.

## Commands
- run: 
```bash
source venv/bin/activate; python3 src/app.py data/tags.csv data/videos.csv
```
- install: 
```bash
bash make.sh __install; source venv/bin/activate; pip3 install -r requirements.txt
```
- test: 
```bash
source venv/bin/activate; py.test -p no:warnings
```