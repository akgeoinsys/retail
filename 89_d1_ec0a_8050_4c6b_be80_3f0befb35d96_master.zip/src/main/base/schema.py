from pyspark.sql.types import StructType, StringType, StructField, IntegerType, LongType

videos = StructType([
    StructField("videoId", StringType()),
    StructField("title", StringType()),
    StructField("views", LongType()),
    StructField("likes", IntegerType()),
    StructField("dislikes", IntegerType())
])

tags = StructType([
    StructField("videoId", StringType()),
    StructField("tag", StringType())
])
