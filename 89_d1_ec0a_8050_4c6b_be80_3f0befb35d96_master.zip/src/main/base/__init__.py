
import abc

from pyspark.sql.types import StructType
from typing import List
from pyspark.sql import SparkSession, DataFrame


class PySparkJobInterface(abc.ABC):

    def __init__(self):
        self.spark = self.init_spark_session()

    def read_csv(self, input_path: str, schema: StructType = None) -> DataFrame:
        reader = self.spark.read
        if schema is None:
            return reader.options(header=True, inferSchema=True).csv(input_path)
        else:
            return reader.options(header=True).schema(schema).csv(input_path)

    @abc.abstractmethod
    def most_common_tags(self, tags: DataFrame, n: int) -> List[str]:
        raise NotImplementedError

    @abc.abstractmethod
    def top_n_videos_by_likes_to_dislikes_ratio(self, videos: DataFrame, tags: DataFrame, limit: int = 3) -> DataFrame:
        raise NotImplementedError

    def stop(self) -> None:
        self.spark.stop()
