from pyspark.sql import DataFrame
from main.base import PySparkJobInterface
import pyspark.sql.functions as F
from typing import List
from pyspark.sql import SparkSession



class PySparkJob(PySparkJobInterface):

    def init_spark_session(self) -> SparkSession:
        spark = SparkSession.builder \
            .appName("Sample PySpark Job") \
            .getOrCreate()
        return spark

    def top_n_videos_by_views(self, videos: DataFrame, n: int) -> DataFrame:
        # Write your code here

    def top_n_videos_by_likes(self, videos: DataFrame, n: int) -> DataFrame:
        # Write your code here

    def top_n_videos_by_likes_to_dislikes_ratio(self, videos: DataFrame, n: int) -> DataFrame:
        # Write your code here

    def most_common_tags(self, tags: DataFrame, n: int) -> List[str]:
        # Write your code here