import sys
import main.base.schema as schema
from main.job.pipeline import PySparkJob

videos_path = sys.argv[1]
tags_path = sys.argv[2]

def main():
    job = PySparkJob()

    # Load input data to DataFrame
    print("<<Reading>>")
    videos = job.read_csv(videos_path, schema.videos)
    tags = job.read_csv(tags_path, schema.tags)

    print("<<Top 3 Videos by Views>>")
    top_videos_by_views = job.top_n_videos_by_views(videos, 3)
    top_videos_by_views.show()

    print("<<Top 3 Videos by Likes>>")
    top_videos_by_likes = job.top_n_videos_by_likes(videos, 3)
    top_videos_by_likes.show()

    print("<<Top 3 Videos by Likes-to-Dislikes Ratio>>")
    top_videos_by_likes_to_dislikes_ratio = job.top_n_videos_by_likes_to_dislikes_ratio(videos, 3)
    top_videos_by_likes_to_dislikes_ratio.show()

    print("<<Top 3 Most Common Tags>>")
    most_common_tags = job.most_common_tags(tags, 3)
    print(most_common_tags)

    job.stop()

if __name__ == '__main__':
    main()
