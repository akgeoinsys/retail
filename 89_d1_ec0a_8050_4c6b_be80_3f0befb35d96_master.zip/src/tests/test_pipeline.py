import pytest
from pyspark.sql import SparkSession
from main.job.pipeline import PySparkJob
from main.base import schema
from typing import List

job = PySparkJob()

videos_sample = [
    ("1", "Video A", 100, 50, 5),
    ("2", "Video B", 200, 120, 20),
    ("3", "Video C", 150, 80, 10),
    ("4", "Video D", 90, 30, 6),
]

tags_sample = [
    ("1", "technology"),
    ("1", "gadgets"),
    ("2", "sports"),
    ("2", "fitness"),
    ("3", "technology"),
    ("3", "computers"),
    ("4", "movies"),
    ("4", "entertainment"),
]

def create_sample(sample, data_schema):
    return job.spark.createDataFrame(data=sample, schema=data_schema)

@pytest.mark.filterwarnings("ignore")
def test_top_n_videos_by_views():
    videos = create_sample(videos_sample, schema.videos)

    top_2_videos = job.top_n_videos_by_views(videos, 2).collect()

    assert len(top_2_videos) == 2
    assert top_2_videos[0].videoId == "2"
    assert top_2_videos[1].videoId == "3"

@pytest.mark.filterwarnings("ignore")
def test_top_n_videos_by_likes():
    videos = create_sample(videos_sample, schema.videos)

    top_2_videos = job.top_n_videos_by_likes(videos, 2).collect()

    assert len(top_2_videos) == 2
    assert top_2_videos[0].videoId == "2"
    assert top_2_videos[1].videoId == "3"

@pytest.mark.filterwarnings("ignore")
def test_top_n_videos_by_likes_to_dislikes_ratio():
    videos = create_sample(videos_sample, schema.videos)

    top_2_videos = job.top_n_videos_by_likes_to_dislikes_ratio(videos, 2).collect()

    assert len(top_2_videos) == 2
    assert top_2_videos[0].videoId == "1"
    assert top_2_videos[1].videoId == "3"

@pytest.mark.filterwarnings("ignore")
def test_most_common_tags():
    tags = create_sample(tags_sample, schema.tags)
    top_3_tags = job.most_common_tags(tags, 3)
    assert len(top_3_tags) == 3
    assert set(["technology", "computers", "movies"]).issubset(top_3_tags)
    

